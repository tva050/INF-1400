## Run program
You can run the program by, locate the file in cmd and use the comand:
    python boids_simulation.py
The program will then run and the simulation will start.