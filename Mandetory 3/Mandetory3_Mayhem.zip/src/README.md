# Mayhem 

Run the program in cmd with: python start_game.py

Click on the shown buttons in the main menu screen with the mousepad, to do any actions. 

Buttons shown in the main menu:
- Play: Starts the game
- Info: All necessary info about the game and how to play